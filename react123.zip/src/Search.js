import React,{Component} from 'react';
import {Redirect} from 'react-router-dom';
import './App.css';

class Search extends Component{
  constructor(props){
    super(props);
    this.state = {
      planetName : "",
      planetResults : [],
      planetDetails : null
  }
  this.handleChange = this.handleChange.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleLogout = this.handleLogout.bind(this);
  this.handleFullDetails = this.handleFullDetails.bind(this);
}

handleSubmit(e) {
  e.preventDefault();
  fetch('https://swapi.co/api/planets/?search='+this.state.planetName)
  .then(responseJson => responseJson.json())
  .then(result => {result = result.results
    this.setState({planetResults:result});
});
}

handleFullDetails(e,itemName){
  e.preventDefault();
  for(var i=0;i<this.state.planetResults.length;i++)
  {
    if(itemName == this.state.planetResults[i].name)
    {
      this.setState({planetDetails:this.state.planetResults[i]});
    }
  }
}

handleLogout(){
  localStorage.removeItem('loggedIn');
  this.props.history.push("/");
}

handleChange(event,type) {
  this.setState({[type]:event.target.value});
}
    render()
    {  
      if(localStorage.getItem('loggedIn') == "false" || localStorage.getItem('loggedIn') == null)
      this.props.history.push("/");

      if(this.state.planetDetails != null)
      {
        this.props.history.push({
          pathname: 'planetDetails',
          state: { planetDetailsJson: this.state.planetDetails}
        });
      }
      
      var arrProper = this.state.planetResults;
      if(arrProper.length == 2) {
      }
      var arrUnknown = [];  
      var arrFinalProper = [];
      for(var i=0; i<arrProper.length; i++)
      {
        if(arrProper[i].population === "unknown")
        {
          arrUnknown.push(arrProper[i]);
        }
        else
        {
          arrFinalProper.push(arrProper[i]);
        }
      }
      var unknownPopulationPlanets = arrUnknown.map( (item,index) => 
      {
        var count = 1+index;
          return (            
          <div style={{display: "flex", flex:1,flexGrow:0, flexDirection: "column",width:`600px`}}>
            <span onClick={e => this.handleFullDetails(e,item.name)} style={{display: "flex", flex:1, flexGrow:0, width:`300px`}}>{count}) Name: {item.name}</span>
            <span style={{display: "flex", flex:1, flexGrow:0, width: `300px`,backgroundColor:"red"}}>Population: {item.population}</span>
          </div>
        );
      } 
    );

    arrFinalProper.sort((a,b) => (Number(a.population) > Number(b.population)) ? 1 : -1);
    var knownPopulationPlanets = arrFinalProper.map( (item, index) =>
      {
        var temp = (index+10)*50;
        var count = (unknownPopulationPlanets.length+1) + index;
        return (            
          <div style={{display: "flex", flex:1,flexGrow:0, flexDirection: "column", width:`600px`}}>
            <span onClick={e => this.handleFullDetails(e,item.name)} style={{display: "flex", flex:1,flexGrow:0, width:`300px`}}>{count}) Name: {item.name}</span>
            <span style={{display: "flex", flex:1,flexGrow:0, width:`${temp}px`,backgroundColor:"green"}}>Population: {Number(item.population)}</span>
          </div>
        );
      }
    );

      return(
        <div className="App">
        <header className="App-header">
        <input type="button" name="logoutButton" value="Logout" onClick = {this.handleLogout}/>
          <h1>Search Planets</h1>
          <form>
            <div>Enter Planet Name : <input type="text" name="planetName" value={this.state.planetName} onChange = {e => this.handleChange(e,"planetName")}/></div>
            <div><input type="submit" name="submitButton" value="Submit" onClick = {this.handleSubmit}/></div> 
          </form>
          <div style={{display: "flex", flex:1, flexDirection: "column"}}>
            {unknownPopulationPlanets}
            {knownPopulationPlanets}
          </div>
        </header>
      </div>
      );
    }
  }
  
  export default Search;